import React from 'react';
import PropTypes from 'prop-types';
import './ModalClientes.css';
import '../Css/Main.css';
import closeIcon from '../../assets/svg/close.svg';
import closeBlackIcon from '../../assets/svg/close_black.svg';

function ModalClientes({
   isOpen,
  variant = 'default',
  title,
  onClose,
  children,
  footer,
  formProps,
  modalId,
}) {
  if (!isOpen) {
    return null;
  }

  const isDelete = variant === 'delete';
  const containerClass = isDelete ? 'clientes-modal-delete' : 'clientes-modal';
  const hasSpecificBackdrop = ['add', 'edit', 'view', 'delete', 'default'].includes(variant);
  const backdropClass = hasSpecificBackdrop ? `clientes-modal-backdrop-${variant}` : 'clientes-modal-backdrop';
  const CloseButtonIcon = isDelete ? closeBlackIcon : closeIcon;

  const Wrapper = formProps ? 'form' : 'div';
  const wrapperClassName = formProps?.className
    ? `${formProps.className} clientes-modal-body-wrapper`.trim()
    : 'clientes-modal-body-wrapper';
  const wrapperProps = formProps
    ? { ...formProps, className: wrapperClassName }
    : { className: wrapperClassName };

  const footerContent = footer ? (
    <div className="clientes-modal-footer">
      {footer}
    </div>
  ) : null;

  return (
    <>
      <div className={backdropClass} onClick={onClose}></div>
      <div id={modalId} className={containerClass}>
        <div className="clientes-modal-content">
          <div className="clientes-modal-header">
            <h2>{title}</h2>
            <button type="button" className={isDelete ? 'clientes-modal-close-delete-btn' : 'clientes-modal-close-btn'} onClick={onClose}>
              <img src={CloseButtonIcon} alt="Fechar" />
            </button>
          </div>

          <Wrapper {...wrapperProps}>
            <div className="clientes-modal-body">
              {children}
            </div>
            {formProps ? footerContent : null}
          </Wrapper>

          {!formProps ? footerContent : null}
        </div>
      </div>
    </>
  );
}

ModalClientes.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  variant: PropTypes.oneOf(['default', 'add', 'edit', 'view', 'delete']),
  title: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
  children: PropTypes.node,
  footer: PropTypes.node,
  formProps: PropTypes.shape({
    onSubmit: PropTypes.func,
    className: PropTypes.string,
    id: PropTypes.string,
  }),
  modalId: PropTypes.string,
};

export default ModalClientes;